# Vital Three Initiative — GitHub Pages reconstruction

This is a **new static reconstruction** of the publicly visible Vital Three Initiative website at https://51-170-139-155.sslip.io/ (inspected November 2026). It is **not** the original private source code or an exact pixel-perfect clone.

## Publish for free

1. Create a **public** GitHub repository named `yourusername.github.io` (replace `yourusername` with your actual GitHub username).
2. Upload `index.html` to the **root** of that repository.
3. Open **Settings → Pages** and select **Deploy from a branch**, branch `main`, folder `/(root)`; save.
4. Visit `https://yourusername.github.io/` after GitHub Pages finishes deploying.

Alternatively, any repository name works and the site will usually be at `https://yourusername.github.io/repository-name/`.

## Important limitations

- The registration dashboard is a **local browser demo**, not a real event registration system. Entries are stored in localStorage on that device only, and include personal information. For a public deployment, replace it with a trusted form provider or backend and clear test entries.
- Contact and newsletter forms open the visitor's email app; they do **not** store submissions or automatically subscribe anyone.
- Original downloadable PDFs, original images, animated logo, and server-side functionality could not be retrieved. The resources are shown as descriptions only.
- The original event dates (July/August 2026) are in the past as of November 2026. Update them before advertising sessions.
- Team identities, credentials, statistics, and scientific/medical statements are copied or paraphrased from the public website and **must be verified** before publication.
- No paid domain is required. GitHub Pages provides a free `github.io` subdomain.
